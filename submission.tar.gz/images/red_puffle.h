/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x25 red_puffle red_puffle.png 
 * Time-stamp: Friday 04/09/2021, 02:54:03
 * 
 * Image Information
 * -----------------
 * red_puffle.png 30@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RED_PUFFLE_H
#define RED_PUFFLE_H

extern const unsigned short red_puffle[750];
#define RED_PUFFLE_SIZE 1500
#define RED_PUFFLE_LENGTH 750
#define RED_PUFFLE_WIDTH 30
#define RED_PUFFLE_HEIGHT 25

#endif

