/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x25 brown_puffle brown_puffle.png 
 * Time-stamp: Friday 04/09/2021, 02:53:37
 * 
 * Image Information
 * -----------------
 * brown_puffle.png 30@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BROWN_PUFFLE_H
#define BROWN_PUFFLE_H

extern const unsigned short brown_puffle[750];
#define BROWN_PUFFLE_SIZE 1500
#define BROWN_PUFFLE_LENGTH 750
#define BROWN_PUFFLE_WIDTH 30
#define BROWN_PUFFLE_HEIGHT 25

#endif

