About the project

This game has a start screen, play screen, and win screen. When in the start
screen, press enter to continue to the play screen. When in the play screen,
there are nine puffles gliding around the screen. Use the up, down, left,
right arrow keys to move the panguin around to capture all the puffles. The score
label at the bottom right corner keeps track of how many puffles you've captured.
Once you capture all the puffles, the win screen shows up. At any point in the game,
you can go back to the start screen by pressing the backspace key.



image citations

penguin
https://theoutline.com/post/1235/the-last-days-of-club-penguin-users-rage-and-rebel

puffles
https://www.redbubble.com/i/ipad-case/Club-Penguin-Oldschool-Puffles-by-winkatawink/33278755.MNKGF

snow_scene
https://clubpenguin.fandom.com/wiki/Dock

start_screen
https://clubpenguin.fandom.com/wiki/Login_Screen

win_screen
http://jenisonajourney.com/2009/06/16/club-penguins-101-days-of-fun-2.html

lose_screen
https://twitter.com/notmycp
