#ifndef SETUP_H
#define SETUP_H

#include "gba.h"
#include "main.h"

void setup(void);
void control(u32 currentButtons, u32 previousButtons);

#endif