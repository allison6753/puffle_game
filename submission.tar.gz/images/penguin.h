/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=40x30 penguin penguin.png 
 * Time-stamp: Friday 04/09/2021, 21:48:49
 * 
 * Image Information
 * -----------------
 * penguin.png 40@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PENGUIN_H
#define PENGUIN_H

extern const unsigned short penguin[1200];
#define PENGUIN_SIZE 2400
#define PENGUIN_LENGTH 1200
#define PENGUIN_WIDTH 40
#define PENGUIN_HEIGHT 30

#endif

