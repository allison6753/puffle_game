/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x25 gray_puffle gray_puffle.png 
 * Time-stamp: Friday 04/09/2021, 02:51:45
 * 
 * Image Information
 * -----------------
 * gray_puffle.png 30@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GRAY_PUFFLE_H
#define GRAY_PUFFLE_H

extern const unsigned short gray_puffle[750];
#define GRAY_PUFFLE_SIZE 1500
#define GRAY_PUFFLE_LENGTH 750
#define GRAY_PUFFLE_WIDTH 30
#define GRAY_PUFFLE_HEIGHT 25

#endif

