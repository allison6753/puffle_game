/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 snow_scene snow_scene.png 
 * Time-stamp: Friday 04/09/2021, 14:37:26
 * 
 * Image Information
 * -----------------
 * snow_scene.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SNOW_SCENE_H
#define SNOW_SCENE_H

extern const unsigned short snow_scene[38400];
#define SNOW_SCENE_SIZE 76800
#define SNOW_SCENE_LENGTH 38400
#define SNOW_SCENE_WIDTH 240
#define SNOW_SCENE_HEIGHT 160

#endif

