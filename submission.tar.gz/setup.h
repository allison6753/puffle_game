#ifndef SETUP_H
#define SETUP_H

#include "gba.h"
#include "main.h"

void setup(void);

#endif