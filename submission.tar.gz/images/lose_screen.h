/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 lose_screen lose_screen.png 
 * Time-stamp: Saturday 04/10/2021, 03:10:27
 * 
 * Image Information
 * -----------------
 * lose_screen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSE_SCREEN_H
#define LOSE_SCREEN_H

extern const unsigned short lose_screen[38400];
#define LOSE_SCREEN_SIZE 76800
#define LOSE_SCREEN_LENGTH 38400
#define LOSE_SCREEN_WIDTH 240
#define LOSE_SCREEN_HEIGHT 160

#endif

