/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x25 green_puffle green_puffle.png 
 * Time-stamp: Friday 04/09/2021, 02:52:06
 * 
 * Image Information
 * -----------------
 * green_puffle.png 30@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GREEN_PUFFLE_H
#define GREEN_PUFFLE_H

extern const unsigned short green_puffle[750];
#define GREEN_PUFFLE_SIZE 1500
#define GREEN_PUFFLE_LENGTH 750
#define GREEN_PUFFLE_WIDTH 30
#define GREEN_PUFFLE_HEIGHT 25

#endif

