/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x25 purple_puffle purple_puffle.png 
 * Time-stamp: Friday 04/09/2021, 03:59:54
 * 
 * Image Information
 * -----------------
 * purple_puffle.png 30@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PURPLE_PUFFLE_H
#define PURPLE_PUFFLE_H

extern const unsigned short purple_puffle[750];
#define PURPLE_PUFFLE_SIZE 1500
#define PURPLE_PUFFLE_LENGTH 750
#define PURPLE_PUFFLE_WIDTH 30
#define PURPLE_PUFFLE_HEIGHT 25

#endif

