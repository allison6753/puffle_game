/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x25 white_puffle white_puffle.png 
 * Time-stamp: Friday 04/09/2021, 02:54:18
 * 
 * Image Information
 * -----------------
 * white_puffle.png 30@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WHITE_PUFFLE_H
#define WHITE_PUFFLE_H

extern const unsigned short white_puffle[750];
#define WHITE_PUFFLE_SIZE 1500
#define WHITE_PUFFLE_LENGTH 750
#define WHITE_PUFFLE_WIDTH 30
#define WHITE_PUFFLE_HEIGHT 25

#endif

