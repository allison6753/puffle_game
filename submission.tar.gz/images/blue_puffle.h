/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x25 blue_puffle blue_puffle.png 
 * Time-stamp: Friday 04/09/2021, 02:55:30
 * 
 * Image Information
 * -----------------
 * blue_puffle.png 30@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLUE_PUFFLE_H
#define BLUE_PUFFLE_H

extern const unsigned short blue_puffle[750];
#define BLUE_PUFFLE_SIZE 1500
#define BLUE_PUFFLE_LENGTH 750
#define BLUE_PUFFLE_WIDTH 30
#define BLUE_PUFFLE_HEIGHT 25

#endif

